module.exports = {
    baseUrl: "mongodb+srv://admin123:adm123456@mini-vc8ws.mongodb.net/test?retryWrites=true&w=majority",
};