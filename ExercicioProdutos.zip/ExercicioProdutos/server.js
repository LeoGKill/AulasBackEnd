const app = require('./app')

app.listen(8080, () => {
    console.log("Na porta 8080");
  });